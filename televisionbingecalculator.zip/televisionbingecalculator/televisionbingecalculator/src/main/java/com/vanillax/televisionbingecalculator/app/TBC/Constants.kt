package com.vanillax.televisionbingecalculator.app.TBC

class Constants
{
     object TVBC_Constants {
        const val API_KEY = "1e4890cd4f30dab070baf9672def4f17"
         const val BASE_IMAGE_PATH = "https://image.tmdb.org/t/p/w500"
         const val BASE_IMAGE_PATH_LARGE = "https://image.tmdb.org/t/p/w1280"
    }
}