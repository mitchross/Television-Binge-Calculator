package com.vanillax.televisionbingecalculator.app.ServerAPI.TVBCLogger;

/**
 * Created by mitchross on 6/7/15.
 */
public class EmptyResponse
{
}
